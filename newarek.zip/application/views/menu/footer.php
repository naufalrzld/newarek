<div class="foot">
    <div class="row mt-logo">
        <div class="col-1 logo_foot">
            <!-- <div class="logo_foot"></div> -->
        </div>
        <div class="col-3">
            <p class="copyright">Copyright &copy; <?php echo date("Y");?> &bull; All right Reserved. Aplikasi Rekrutmen Mobile Innovation Laboratory | Developed by PATRA</p>
        </div>
    </div>
</div>