<div class="timeline">
  <div class="container bulat">
    <div class="content">
      <h5>Open Registration</h5>
      <p>15 Maret - 22 Maret 2018</p>
    </div>
  </div>
  <div class="container bulat">
    <div class="content">
      <h5>Open Mind & Closed Registeration</h5>
      <p>22 Maret 2018</p>
    </div>
  </div>
<div class="container bulat">
    <div class="content">
      <h5>Pengumuman Tahap 1</h5>
      <p>23 Maret 2018</p>
    </div>
  </div>
<div class="container bulat">
    <div class="content">
      <h5>Tes tulis</h5>
      <p>25 Maret 2018</p>
    </div>
  </div>
<div class="container bulat">
    <div class="content">
      <h5>Wawancara</h5>
      <p>26 - 31 Maret 2018</p>
    </div>
  </div>

<div class="container bulat">
    <div class="content">
      <h5>Pengumuman Tahap 2</h5>
      <p>6 April 2018</p>
    </div>
  </div>
<div class="container bulat">
    <div class="content">
      <h5>First Meet</h5>
      <p>7 April 2018</p>
    </div>
  </div>
</div>