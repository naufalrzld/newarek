<?php

echo exec("git stash");
echo exec("git pull");